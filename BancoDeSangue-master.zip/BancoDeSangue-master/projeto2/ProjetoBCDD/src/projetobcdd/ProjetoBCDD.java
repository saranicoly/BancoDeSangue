package projetobcdd;
import javax.swing.*;
public class ProjetoBCDD {
    public static void main(String[] args) {
        Inicio janelaCPF = new Inicio();
        janelaCPF.setVisible(true);
        
    }
    
}