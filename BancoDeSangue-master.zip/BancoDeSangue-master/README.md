# BancoDeSangue
Programa para cadastro de usuários em banco de sangue, feito em Java integrado com banco de dados.
